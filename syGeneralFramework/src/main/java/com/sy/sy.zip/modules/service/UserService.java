package com.sy.modules.service;

import java.util.List;
import java.util.Map;

/**
 * @Author:liangjilong
 * @Date:2015年10月29日-下午3:45:04
 * @Email:jilonglinag@sina.com
 * @Version:1.0
 * @Description:
 */
public interface UserService   {
	public 	List<Map<String, Object>> getAll();
}
