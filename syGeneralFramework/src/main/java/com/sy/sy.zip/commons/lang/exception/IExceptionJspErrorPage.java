package com.sy.commons.lang.exception;
/**
 * 定义一标记接口，实现该接口的异常，错误处理时通过jsp错误页面方式显示
 * 创建日期：2012-12-20
 * @author niezhegang
 */
public interface IExceptionJspErrorPage {

}
