package com.sy.commons.persistence.annotation;

/**
 * @Author:liangjilong
 * @Date:2015年10月29日-下午3:45:04
 * @Email:jilonglinag@sina.com
 * @Version:1.0
 * @Description:
 */
public interface Table {
	String USER = "USER";
	
	
	String BUS_RELATION_TEMP = "BUS_RELATION_TEMP";
	String TEMPLATE = "TEMPLATE";
	String TEMPLATE_INFO = "TEMPLATE_INFO";
	String TEST = "TEST";
	String BOILER_REPORT_INFO = "BOILER_REPORT_INFO";

}
